﻿int row =  14;

for (int i = 1; i<= row; i++)
{
    if(i == 7 || i == 8)
    {
        Console.WriteLine("************");
    } else
    {
        Console.WriteLine("*          *");
    }


}


