﻿string word =Console.ReadLine();


char[] array = word.ToCharArray();

foreach (char c in array)
{
    Console.WriteLine(c);
}